package com.example.toiletsforyou;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class Main3Activity extends AppCompatActivity {
    List<Product> productList;
    //the recyclerview
    RecyclerView recyclerView;
    FirebaseAuth fire;
    private FirebaseAuth.AuthStateListener listener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        productList = new ArrayList<>();

        productList.add(
                new Product(
                        1,
                        "Dadar West Sulabh Toilet",
                        "Rd Number 86, Chandrakant Dhuru Wadi, Dadar West, Mumbai, Maharashtra 400028",

                        R.drawable.ic_swachh_bharat));

        productList.add(
                new Product(
                        2,
                        "Public Toilet- Shivaji Park",
                        "S.V.S Road, Dadar West, Shivaji Park, Mumbai, Maharashtra 400016",

                        R.drawable.ic_swachh_bharat));

        productList.add(
                new Product(
                        3,
                        "Public Toilet",
                        "DS Babrekar Marg, Near Kabutar khana, Dadar West, Dadar, Mumbai, Maharashtra 400028",
                        R.drawable.ic_swachh_bharat));
        productList.add(
                new Product(
                        4,
                        "Public Restroom",
                        "Dadar West, Shivaji Park, Mumbai, Maharashtra 400028",

                        R.drawable.ic_swachh_bharat));

        productList.add(
                new Product(
                        5,
                        "Public Toilet",
                        "Veer Kotwal Udyan Chowk, Dadar West, Dadar, Mumbai, Maharashtra 400028",

                        R.drawable.ic_swachh_bharat));

        productList.add(
                new Product(
                        6,
                        "SBM Toilet",
                        "Mohan Nivas, Near Shivaji Park, Keluskar Road, Dadar West, Dadar, Mumbai, Maharashtra, 400028",

                        R.drawable.ic_swachh_bharat));
        productList.add(
                new Product(
                        7,
                        "Dadar Station Public Toilet",
                        "Dadar Station Over Bridge, Dadar East, Dadar, Mumbai, Maharashtra 400028",

                        R.drawable.ic_swachh_bharat));

        //creating recyclerview adapter
        final ProductAdapter adapter = new ProductAdapter(this, productList);
        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new ProductAdapter.OnItemClickListener() {
            @Override
            public void onItemclick(int position) {
                productList.get(position);
                if(position==0){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Dadar+West+Sulabh+Toilet/@19.0205057,72.8347441,16z/data=!4m8!1m2!2m1!1sDadar+West+Sulabh+Toilet!3m4!1s0x3be7cec443386b6d:0xbff1546a68d7a9e4!8m2!3d19.019596!4d72.8359866"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);

                }
                else
                if (position==1){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Public+Toilet-+Shivaji+Park/@19.0284307,72.8354908,17z/data=!4m8!1m2!2m1!1spublic+toilet-+shivaji+park!3m4!1s0x3be7cece6de0800b:0xc0309ae2a230c046!8m2!3d19.0285963!4d72.8378099"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }
                else
                if (position==2){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Public+Toilet/@19.0211496,72.8375865,17z/data=!4m8!1m2!2m1!1sPublic+Toilet:-DS+Babrekar+Marg,+Near+Kabutar+khana,+Dadar+West,+Dadar,+Mumbai,+Maharashtra+400028!3m4!1s0x3be7cedad5575213:0x495d29a93e0388f2!8m2!3d19.0211496!4d72.8397752"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }
                else
                if(position==3) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Public+Restroom/@19.0211747,72.8310204,15z/data=!4m8!1m2!2m1!1spublic+restrooms!3m4!1s0x3be7cece687b86a3:0x4a73368bf6bd28e7!8m2!3d19.0282549!4d72.837549"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }
                else
                if (position==4){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Public+Toilet/@19.0215689,72.840025,17z/data=!3m1!4b1!4m5!3m4!1s0x3be7cedafe721413:0x1b4262cd19c976c6!8m2!3d19.0215638!4d72.8422137"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }

                else if (position==5){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/SBM+Toilet/@19.0265603,72.8374161,17z/data=!3m1!4b1!4m5!3m4!1s0x3be7cecfd5c45555:0x9c010e852ab4fe11!8m2!3d19.0265552!4d72.8396048"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }
                else if (position==6){
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/place/Dadar+Station+Public+Toilet/@19.0265854,72.83085,15z/data=!4m8!1m2!2m1!1sDadar+Station+Public+Toilet!3m4!1s0x3be7cf341881bccb:0xa5756f7ee2e1039!8m2!3d19.019714!4d72.8430841"));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    browserIntent.setPackage("com.google.android.apps.maps");
                    startActivity(browserIntent);
                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.item2:

                fire.getInstance().signOut();
                Intent n= new Intent( this,MainActivity.class);
                startActivity(n);

                return  true;

            case R.id.item3:
                Intent intent2=new Intent(getApplicationContext(),setting.class);
                startActivity(intent2);
                return  true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
