package com.example.toiletsforyou;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Main2Activity extends AppCompatActivity {
    EditText e1,e2,e3;
    Button b1;
    ImageView img;
    TextView t1;
     FirebaseAuth mfire;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mfire=FirebaseAuth.getInstance();
        e1=findViewById(R.id.ed1);
        e2=findViewById(R.id.ed2);
        e3=findViewById(R.id.ed3);
        b1=findViewById(R.id.br);
        img=findViewById(R.id.img);
        t1=findViewById(R.id.tr);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=e1.getText().toString();
                String pass=e2.getText().toString();
                String cpss=e3.getText().toString();
                if(email.isEmpty()){
                    e1.setError("Please enter email id");
                    e1.requestFocus();
                }
                else if (pass.isEmpty()){
                    e2.setError("Please Enter Your Password");
                    e2.requestFocus();
                }
                else if (cpss.isEmpty()){
                    e3.setError("Please Enter Confirm Password");
                    e3.requestFocus();
                }
                else if (!(email.isEmpty() && pass.isEmpty())){
                    mfire.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(Main2Activity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){

                                Intent i =new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(i);
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"Login Unsccessful, Please try again", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
                else {
                    Toast.makeText(getApplicationContext(),"Error Ocurred!", Toast.LENGTH_LONG).show();
                }
            }
        });
 t1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i =new Intent(getApplicationContext(),MainActivity.class);
        startActivity(i);
    }
});
    }
}
