package com.example.toiletsforyou;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks {
    EditText e1l,e2l,e3l;
    Button b2;
    ImageView img;
    CheckBox check;
    GoogleApiClient gclient;
    String Sitekey="6LcyFugUAAAAAP-MXmhKQgG_h7A14y9hUv-R2WU9";
    TextView t2;
    FirebaseAuth mfire;
    private FirebaseAuth.AuthStateListener mauthStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mfire=FirebaseAuth.getInstance();
        e1l=findViewById(R.id.ed1l);
        e2l=findViewById(R.id.ed2l);
        b2=findViewById(R.id.bl);
        img=findViewById(R.id.img);
        t2=findViewById(R.id.tl);
        check = findViewById(R.id.check);
        gclient=new GoogleApiClient.Builder(this).addApi(SafetyNet.API).addConnectionCallbacks(MainActivity.this).build();
        gclient.connect();

//
//        if (mfire.getCurrentUser() != null) {
//            // User is logged in
//            startActivity(new Intent(this, Main3Activity.class));
//            finish();
//        }


        mauthStateListener=new FirebaseAuth.AuthStateListener() {


            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser= mfire.getCurrentUser();
                if( mfire != null){
                    Toast.makeText(getApplicationContext(),"You are Logged in",Toast.LENGTH_LONG).show();
                    Intent i = new Intent(getApplicationContext(),Main3Activity.class);
                    startActivity(i);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Please Login",Toast.LENGTH_LONG).show();
                }
            }
        };
        check.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (check.isChecked()){
                    SafetyNet.SafetyNetApi.verifyWithRecaptcha(gclient,Sitekey).setResultCallback(new ResultCallback<SafetyNetApi.RecaptchaTokenResult>() {
                        @Override
                        public void onResult(@NonNull SafetyNetApi.RecaptchaTokenResult recaptchaTokenResult) {
                            Status status= recaptchaTokenResult.getStatus();
                            if ((status!=null)&& status.isSuccess()){
                                Toast.makeText(getApplicationContext(),"Your Ready to Login", Toast.LENGTH_LONG).show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(),"Login Error , please Login Again", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });
b2.setOnClickListener(new OnClickListener() {
    @Override
    public void onClick(View v) {
        String email=e1l.getText().toString();
        String pass=e2l.getText().toString();

        if(email.isEmpty()){
            e1l.setError("Please enter email id");
            e1l.requestFocus();
        }
        else if (pass.isEmpty()){
            e2l.setError("Please Enter Your Password");
            e2l.requestFocus();
        }
        else if (!check.isChecked()){
            Toast.makeText(getApplicationContext(),"Please verify Your Not Robot", Toast.LENGTH_LONG).show();
        }

        else if (!(email.isEmpty() && pass.isEmpty()) && check.isChecked()){
            mfire.signInWithEmailAndPassword(email, pass).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()){
                        Toast.makeText(getApplicationContext(),"Login Error , please Login Again", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Intent intent = new Intent(getApplicationContext(),Main3Activity.class);
                        startActivity(intent);
                    }
                }
            });
        }
        else {
            Toast.makeText(getApplicationContext(),"Error Ocurred!", Toast.LENGTH_LONG).show();
        }
    }
});
        t2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(getApplicationContext(), Main2Activity.class);
                startActivity(in);
            }
        });


    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }
}
